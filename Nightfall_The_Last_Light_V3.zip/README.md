# NIGHTFALL: THE LAST LIGHT — V3

A polished multiplayer browser horror foundation.

### New in V3
- Larger Blackwood Asylum map
- Three randomized monsters: The Wraith, The Butcher, The Shade
- Different monster speed/damage/range
- Monster aggression system
- Hiding spots
- Medkits
- Stamina
- Down/revive system
- Room codes for 2–6 players
- Expanded character customization
- Desktop + mobile controls
- Win/lose screen

### Run locally
Install Node.js 18+.
`npm install`
`npm start`
Open `http://localhost:3000`

### Online
Deploy the folder to a Node/WebSocket host such as Render, Railway, Fly.io, etc. Use `npm install` as build command and `npm start` as start command. Share the resulting HTTPS URL.

### Controls
WASD / arrows = move
E = interact
R = revive a nearby teammate
Space = start

This is a browser multiplayer game foundation, not yet a commercial 3D title. Full production would additionally require professional art/animation/audio, authentication, persistent profiles, matchmaking, dedicated infrastructure, anti-cheat, moderation, testing, and more content.
